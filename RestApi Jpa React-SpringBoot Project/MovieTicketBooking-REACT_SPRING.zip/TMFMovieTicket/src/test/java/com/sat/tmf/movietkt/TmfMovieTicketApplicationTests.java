package com.sat.tmf.movietkt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmfMovieTicketApplicationTests {

	@Test
	void contextLoads() {
	}

}
